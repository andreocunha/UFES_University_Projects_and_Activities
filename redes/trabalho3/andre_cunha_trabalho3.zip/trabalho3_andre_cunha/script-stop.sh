tmux kill-window -t rare
tmux kill-window -t telnet