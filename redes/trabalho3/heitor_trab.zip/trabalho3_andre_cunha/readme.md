# Terceiro trabalho de Redes - Roteamento

### Comandos úteis

#### Ping:
```
ping <ip_destino> vrf v1
```	

#### Traceroute:
```
traceroute <ip_destino> vrf v1
```

#### Desligar interface:
```
conf t 
int <interface>
shutdown
exit
```

#### Verificar tabela de rotas:
```
show ipv4 route v1
show ipv6 route v1
```

#### Verificar tráfego de rede:
```
show interface traffic
```