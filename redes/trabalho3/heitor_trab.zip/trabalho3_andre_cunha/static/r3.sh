#!/bin/bash

java -jar ../rtr.jar routersc andre_cunha_r3-hw.txt andre_cunha_r3-sw.txt