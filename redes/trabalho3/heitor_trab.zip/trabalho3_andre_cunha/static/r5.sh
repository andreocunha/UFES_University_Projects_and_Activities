#!/bin/bash

java -jar ../rtr.jar routersc andre_cunha_r5-hw.txt andre_cunha_r5-sw.txt