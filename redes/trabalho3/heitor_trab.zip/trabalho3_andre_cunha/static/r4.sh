#!/bin/bash

java -jar ../rtr.jar routersc andre_cunha_r4-hw.txt andre_cunha_r4-sw.txt