#!/bin/bash

java -jar ../rtr.jar routersc andre_cunha_r2-hw.txt andre_cunha_r2-sw.txt