#!/bin/bash

java -jar ../rtr.jar routersc andre_cunha_r1-hw.txt andre_cunha_r1-sw.txt